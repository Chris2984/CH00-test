package tw.tcnr11.m0501;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.text.DecimalFormat;


public class M0501 extends AppCompatActivity {

    private EditText e001;
    private Button b001;
    private TextView t003;
    private Spinner s002;
    private String sSex;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.m0501);
        setupViewcomponent();
    }
//***********************************************************************************
    private void setupViewcomponent() {//設定物件配置碼
        e001 = (EditText) findViewById(R.id.m0500_e001); //第一輸入欄
        b001 = (Button) findViewById(R.id.m0500_b001); //第一按鈕
        t003 = (TextView) findViewById(R.id.m0500_t003);//第一結果欄
        s002 = (Spinner) findViewById(R.id.m0500_s002);
        ArrayAdapter<CharSequence> s002adp = ArrayAdapter.createFromResource(this, R.array.m0501_s002, android.R.layout.simple_spinner_item);
        //第38行完全看不懂，要搞懂
        s002adp.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        //第40行完全看不懂，要搞懂
        s002.setAdapter(s002adp);
        //第42行完全看不懂，要搞懂
        s002.setOnItemSelectedListener(s002On);
        //第44行應該指  把spinner2號設置成  選擇Item後 聆聽選擇了哪個item

        b001.setOnClickListener(b001On);
        //我第一次想念簡單明瞭的按鈕
    }
//***********************************************************************************
    private AdapterView.OnItemSelectedListener s002On=new AdapterView.OnItemSelectedListener() {
    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        sSex = parent.getSelectedItem().toString();
    }
//還是看不懂，AdapterView是做甚麼的???
    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
};

//***********************************************************************************
    private View.OnClickListener b001On = new View.OnClickListener() {
    //這下面與按鍵動作有關，由於按下去後才開始判斷性別、年齡和對應，所以判斷式寫這邊

        @Override
        public void onClick(View v) {
            if(e001.getText().toString().trim().length()!=0) { //判斷字數數目>0(因為有!)，這裡繼續執行
                //確認有輸入年齡，開始思考後面的年齡、性別問題
                String Strsug0 = getString(R.string.m0501_t006);
                int iage = Integer.parseInt(e001.getText().toString());

                if (sSex.equals(getString(R.string.chk01))) {
                    //在性別為男的狀況下
                    if (iage < 25) {
                        Strsug0 += getString(R.string.m0501_f001);
                    } else if (iage < 30) {
                        Strsug0 += getString(R.string.m0501_f002);
                    } else if (iage >= 30) {
                        Strsug0 += getString(R.string.m0501_f003);
                    }//性別男的條件結束
                        } else
                            {
                    //在性別為女的狀況下
                    if (iage < 25) {
                        Strsug0 += getString(R.string.m0501_f001);
                    } else if (iage < 30) {
                        Strsug0 += getString(R.string.m0501_f002);
                    } else if (iage >= 30) {
                        Strsug0 += getString(R.string.m0501_f003);
                //性別女的條件結束

                        }
                    }//選擇性別結束
                t003.setText(Strsug0);

            }else{
                //判斷字數數目=0(因為有!)，改來這裡執行
                t003.setText(getString(R.string.m0501_h001));
            }
        }//onclickView V程式結束


    };//跟按鈕相關的程式結束
}